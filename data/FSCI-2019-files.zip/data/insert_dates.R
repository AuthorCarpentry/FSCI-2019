# Insert this code in the date: section of the YAML header (place after date: and a space)

"`r format(Sys.Date(), '%A, %B %d, %Y')`"

# Insert this code under the Date of First Version 
`r format(Sys.Date()-60, '%A, %B %d, %Y')`

## Insert this code under the Date of Last Update
`r format(Sys.Date(), '%A, %B %d, %Y')`
